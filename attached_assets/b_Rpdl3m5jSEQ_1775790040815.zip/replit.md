# My Project

A Next.js 16 web application migrated from Vercel to Replit.

## Architecture

- **Framework**: Next.js 16.2.0 (App Router)
- **Styling**: Tailwind CSS v4 with Radix UI components (shadcn/ui)
- **Animations**: Framer Motion, Lenis smooth scroll
- **Package Manager**: pnpm

## Running the App

The app runs on port 5000 via the "Start application" workflow:

```
pnpm run dev
```

This starts Next.js on `0.0.0.0:5000` for Replit compatibility.

## Project Structure

- `app/` — Next.js App Router pages and layouts
- `components/` — Reusable UI components (Radix/shadcn)
- `hooks/` — Custom React hooks
- `lib/` — Utility functions
- `public/` — Static assets
- `styles/` — Global styles

## Key Dependencies

- `next` 16.2.0
- `react` / `react-dom` 19.2.4
- `@radix-ui/*` — Headless UI primitives
- `framer-motion` — Animations
- `tailwindcss` v4 — Styling
- `@vercel/analytics` — Analytics (Vercel-specific, safe to ignore on Replit)
