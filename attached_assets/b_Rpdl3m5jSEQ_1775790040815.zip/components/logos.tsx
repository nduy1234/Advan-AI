"use client"

import { motion } from "framer-motion"

const logos = [
  "Vercel",
  "Stripe",
  "Linear",
  "Notion",
  "Figma",
  "Framer",
  "Webflow",
]

export function Logos() {
  return (
    <section className="py-20 px-6 border-t border-border">
      <motion.p
        initial={{ opacity: 0 }}
        whileInView={{ opacity: 1 }}
        viewport={{ once: true }}
        transition={{ duration: 0.5 }}
        className="text-center text-muted-foreground mb-12"
      >
        <span className="font-medium text-foreground">Over 20,000 creative teams</span>{" "}
        use Motio to create stunning animations online.
      </motion.p>

      <div className="max-w-5xl mx-auto">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="flex flex-wrap justify-center items-center gap-8 md:gap-16"
        >
          {logos.map((logo, index) => (
            <motion.span
              key={logo}
              initial={{ opacity: 0, y: 10 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.4, delay: index * 0.1 }}
              className="text-xl md:text-2xl font-bold text-foreground/60 hover:text-foreground transition-colors cursor-pointer"
            >
              {logo}
            </motion.span>
          ))}
        </motion.div>
      </div>
    </section>
  )
}
