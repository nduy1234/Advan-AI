"use client"

import { motion } from "framer-motion"
import { Laptop, Building2, Briefcase, Rocket, HeadphonesIcon, ShoppingCart } from "lucide-react"

const solutions = [
  {
    icon: Laptop,
    title: "Technology",
    description: "Build your first predictable pipeline without hiring an expensive SDR team. Go from 0 to 10+ demos per month.",
    color: "from-blue-500/10 to-indigo-500/10"
  },
  {
    icon: Building2,
    title: "Financial Services",
    description: "Scale outbound alongside your existing sales motion. Add AI-powered pipeline without adding headcount.",
    color: "from-purple-500/10 to-pink-500/10"
  },
  {
    icon: Briefcase,
    title: "Health & Wellness",
    description: "Fill your consultation pipeline with pre-qualified prospects who need exactly what you offer.",
    color: "from-emerald-500/10 to-teal-500/10"
  },
  {
    icon: Rocket,
    title: "Media & Telecommunications",
    description: "Deploy your runway strategically. Get scalable customer acquisition from day one with guaranteed ROI.",
    color: "from-orange-500/10 to-amber-500/10"
  },
  {
    icon: HeadphonesIcon,
    title: "Travel & Hospitality",
    description: "Reach security-conscious decision-makers and IT leaders with compliant, targeted outreach campaigns.",
    color: "from-cyan-500/10 to-sky-500/10"
  },
  {
    icon: ShoppingCart,
    title: "E-commerce & Retail",
    description: "Re-engage dormant accounts, expand into new verticals, and build supplier or buyer pipelines at scale.",
    color: "from-rose-500/10 to-red-500/10"
  }
]

export function IndustriesSection() {
  return (
    <section id="solutions" className="py-24 lg:py-32 bg-[#F8F7F4] relative overflow-hidden">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="max-w-4xl mx-auto text-center mb-16">
          <motion.p
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-sm font-semibold text-[#E85D04] uppercase tracking-wider mb-6"
          >
            Built for Business Growth
          </motion.p>
          <motion.h2
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: 0.1 }}
            className="text-3xl md:text-4xl lg:text-5xl font-light text-[#1a1a1a] leading-tight mb-6"
            style={{ fontFamily: "var(--font-serif)" }}
          >
            Solutions for our <span className="italic">case studies</span>
          </motion.h2>
          <motion.p
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: 0.2 }}
            className="text-lg text-[#666] max-w-2xl mx-auto"
          >
            Our AI Growth Engine adapts to your specific market, ICP, and sales motion.
          </motion.p>
        </div>

        {/* Solutions Grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {solutions.map((solution, index) => {
            const Icon = solution.icon
            return (
              <motion.div
                key={solution.title}
                initial={{ opacity: 0, y: 40 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.5, delay: index * 0.1 }}
                whileHover={{ y: -8, transition: { duration: 0.3 } }}
                className="group bg-white rounded-2xl p-8 hover:shadow-xl transition-all duration-500 cursor-pointer"
              >
                <div className={`w-14 h-14 rounded-xl bg-gradient-to-br ${solution.color} flex items-center justify-center mb-6 group-hover:scale-110 transition-transform duration-300`}>
                  <Icon className="w-7 h-7 text-[#1a1a1a]" />
                </div>
                <h3 
                  className="text-xl font-semibold text-[#1a1a1a] mb-3"
                  style={{ fontFamily: "var(--font-serif)" }}
                >
                  {solution.title}
                </h3>
                <p className="text-[#666] leading-relaxed">
                  {solution.description}
                </p>
              </motion.div>
            )
          })}
        </div>

        {/* Bottom Statement */}
        <motion.p
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="mt-16 text-center text-lg text-[#666] max-w-3xl mx-auto"
        >
          Every solution includes a curated prospect database, 
          AI-personalized sequences, managed deliverability, and a commitment to{" "}
          <span className="text-[#1a1a1a] font-medium">consistent qualified appointments</span>.
        </motion.p>
      </div>
    </section>
  )
}
