"use client"

import Link from "next/link"
import Image from "next/image"
import { Linkedin, Instagram, Youtube } from "lucide-react"

const footerLinks = {
  platform: [
    { label: "How it Works", href: "#platform" },
    { label: "Solutions", href: "#solutions" },
    { label: "Results", href: "#results" },
    { label: "FAQs", href: "#faq" }
  ],
  company: [
    { label: "About", href: "/about" },
    { label: "Contact", href: "#contact" },
    { label: "Book a Demo", href: "https://cal.com/day-nguyen" }
  ],
  legal: [
    { label: "Privacy Policy", href: "/privacy" },
    { label: "Terms of Service", href: "/terms" }
  ]
}

const XIcon = () => (
  <svg viewBox="0 0 24 24" className="w-5 h-5" fill="currentColor" aria-hidden="true">
    <path d="M18.244 2.25h3.308l-7.227 8.26 8.502 11.24H16.17l-5.214-6.817L4.99 21.75H1.68l7.73-8.835L1.254 2.25H8.08l4.713 6.231zm-1.161 17.52h1.833L7.084 4.126H5.117z" />
  </svg>
)

const socialLinks = [
  { icon: Linkedin, href: "https://www.linkedin.com/company/advanai/", label: "LinkedIn" },
  { icon: Instagram, href: "https://www.instagram.com/advanintech", label: "Instagram" },
  { icon: XIcon, href: "https://x.com/AdvanAI11", label: "X", isCustom: true },
  { icon: Youtube, href: "https://www.youtube.com/@AdvanAI1", label: "YouTube" },
]

export function Footer() {
  return (
    <footer className="bg-[#fefefe] text-[#1a1a1a]">
      <div className="max-w-7xl mx-auto pl-[20px] pr-[20px] pt-[24px] pb-[24px]">
        <div className="grid grid-cols-2 md:grid-cols-5 gap-6 lg:gap-10 mb-6">
          {/* Brand */}
          <div className="col-span-2">
            <Link href="/" className="inline-flex items-center gap-2 mb-3">
              <Image
                src="/advan-logo.png"
                alt="Advan AI"
                width={36}
                height={36}
                className="h-9 w-9"
              />
              <span className="font-semibold text-lg text-[#1a1a1a]">Advan AI</span>
            </Link>
            <p className="text-sm text-[#666] mb-4 max-w-xs">
              AI-Powered Growth Systems for Predictable Revenue
            </p>
            {/* Social Links */}
            <div className="flex items-center gap-2">
              {socialLinks.map((social) => {
                const isCustom = 'isCustom' in social && social.isCustom
                return (
                  <Link 
                    key={social.label}
                    href={social.href} 
                    target="_blank" 
                    rel="noopener noreferrer"
                    className="inline-flex items-center justify-center w-10 h-10 rounded-xl bg-[#1a1a1a]/5 hover:bg-[#1a1a1a]/10 transition-colors"
                    aria-label={social.label}
                  >
                    {isCustom ? (
                      <social.icon />
                    ) : (
                      <social.icon className="w-5 h-5" />
                    )}
                  </Link>
                )
              })}
            </div>
          </div>

          {/* Platform Links */}
          <div>
            <h4 className="font-semibold mb-4 text-sm uppercase tracking-wider text-[#1a1a1a]/50">Platform</h4>
            <ul className="space-y-3">
              {footerLinks.platform.map((link) => (
                <li key={link.label}>
                  <Link 
                    href={link.href} 
                    className="text-sm text-[#666] hover:text-[#1a1a1a] transition-colors"
                  >
                    {link.label}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Company Links */}
          <div>
            <h4 className="font-semibold mb-4 text-sm uppercase tracking-wider text-[#1a1a1a]/50">Company</h4>
            <ul className="space-y-3">
              {footerLinks.company.map((link) => (
                <li key={link.label}>
                  <Link 
                    href={link.href}
                    target={link.href.startsWith("http") ? "_blank" : undefined}
                    rel={link.href.startsWith("http") ? "noopener noreferrer" : undefined}
                    className="text-sm text-[#666] hover:text-[#1a1a1a] transition-colors"
                  >
                    {link.label}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Legal Links */}
          <div>
            <h4 className="font-semibold mb-4 text-sm uppercase tracking-wider text-[#1a1a1a]/50">Legal</h4>
            <ul className="space-y-3">
              {footerLinks.legal.map((link) => (
                <li key={link.label}>
                  <Link 
                    href={link.href} 
                    className="text-sm text-[#666] hover:text-[#1a1a1a] transition-colors"
                  >
                    {link.label}
                  </Link>
                </li>
              ))}
            </ul>
          </div>
        </div>

        {/* Bottom Bar */}
        <div className="pt-4 border-t border-[#1a1a1a]/10 flex flex-col md:flex-row justify-between items-center gap-2">
          <p className="text-sm text-[#999]">
            2026 Advan AI. All rights reserved.
          </p>
          <button
            type="button"
            onClick={() => window.scrollTo({ top: 0, behavior: "smooth" })}
            className="text-sm text-[#999] hover:text-[#1a1a1a] transition-colors"
          >
            Back to top
          </button>
        </div>
      </div>
    </footer>
  )
}
