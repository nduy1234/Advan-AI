"use client"

import { motion } from "framer-motion"
import { Button } from "@/components/ui/button"
import { ArrowRight } from "lucide-react"

export function Hero() {
  return (
    <section className="min-h-screen flex flex-col items-center justify-center pt-16 px-6">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5, delay: 0.2 }}
        className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-accent mb-8"
      >
        <span className="text-sm font-medium text-foreground">New:</span>
        <span className="text-sm text-muted-foreground">Infinite Canvas</span>
        <span className="text-sm text-primary font-medium cursor-pointer hover:underline">
          Learn more
        </span>
      </motion.div>

      <motion.h1
        initial={{ opacity: 0, y: 30 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6, delay: 0.3 }}
        className="text-5xl sm:text-6xl md:text-7xl lg:text-8xl font-bold text-foreground text-center max-w-5xl leading-[1.1] tracking-tight text-balance"
      >
        Super fast motion for every team
      </motion.h1>

      <motion.p
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5, delay: 0.5 }}
        className="mt-8 text-lg md:text-xl text-muted-foreground text-center max-w-2xl text-pretty"
      >
        Create stunning animations and bring your ideas to life with powerful tools designed for modern teams.
      </motion.p>

      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5, delay: 0.7 }}
        className="mt-10"
      >
        <Button
          size="lg"
          className="rounded-full px-8 py-6 text-base bg-primary hover:bg-primary/90 group"
        >
          Try Motio for free
          <ArrowRight className="ml-2 h-4 w-4 transition-transform group-hover:translate-x-1" />
        </Button>
      </motion.div>
    </section>
  )
}
