"use client"

import { motion } from "framer-motion"

export function TeamPhotoSection() {
  return (
    <section className="bg-white">
      <motion.div
        initial={{ opacity: 0, y: 30 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true, margin: "-60px" }}
        transition={{ duration: 0.8, ease: [0.25, 0.1, 0.25, 1] }}
        className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pb-8 lg:pb-12"
      >
        <div className="relative w-full rounded-2xl overflow-hidden shadow-xl">
          {/* eslint-disable-next-line @next/next/no-img-element */}
          <img
            src="/team-diverse.png"
            alt="Diverse team collaborating in a modern office"
            className="w-full object-cover object-center block"
            style={{ maxHeight: 420 }}
          />
          {/* Gradient overlay for caption legibility */}
          <div
            className="absolute inset-0"
            style={{
              background: "linear-gradient(to right, rgba(0,0,0,0.04) 0%, transparent 50%, rgba(0,0,0,0.45) 100%)",
            }}
          />
          {/* Caption */}
          <div className="absolute bottom-0 right-0 p-6 sm:p-8 text-right max-w-xs">
            <p className="text-white text-base sm:text-lg font-light leading-snug drop-shadow-md">
              Built by a team that cares about your growth
            </p>
            <p className="text-white/60 text-sm mt-1 drop-shadow">
              Real humans behind every AI system we deploy
            </p>
          </div>
        </div>
      </motion.div>
    </section>
  )
}
