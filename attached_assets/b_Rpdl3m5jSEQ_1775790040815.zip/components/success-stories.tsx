"use client"

import { motion } from "framer-motion"
import { ArrowRight } from "lucide-react"
import { Button } from "@/components/ui/button"
import Link from "next/link"

const BOOKING_URL = "https://cal.com/day-nguyen"

export function SuccessStories() {
  return (
    <section className="py-8 lg:py-12 bg-[#F8F7F4]" id="results">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="flex flex-col md:flex-row md:items-end md:justify-between gap-6 mb-8">
          <div className="max-w-2xl">
            <motion.p
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              className="text-sm font-semibold text-[#E85D04] uppercase tracking-wider mb-6"
            >
              Proven Results
            </motion.p>
          </div>
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: 0.2 }}
          >
            <Button 
              variant="outline" 
              asChild 
              className="border-[#1a1a1a] text-[#1a1a1a] hover:bg-[#1a1a1a] hover:text-white bg-transparent rounded-full px-6"
            >
              <Link href={BOOKING_URL} target="_blank" rel="noopener noreferrer">
                See your growth potential
                <ArrowRight className="ml-2 w-4 h-4" />
              </Link>
            </Button>
          </motion.div>
        </div>

        {/* Main Success Story Card */}
        <motion.div
          initial={{ opacity: 0, y: 40 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="bg-white rounded-3xl overflow-hidden shadow-lg mb-8"
        >
          <div className="grid lg:grid-cols-2">
            {/* Left - Visual */}
            <div className="relative h-56 lg:h-auto lg:min-h-[320px] overflow-hidden">
              <img
                src="/success-story.jpg"
                alt="Startup team celebrating pipeline growth milestone"
                className="w-full h-full object-cover object-center"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/30 to-transparent" />
              <div className="absolute top-5 left-5">
                <div className="px-3 py-1.5 bg-white/95 backdrop-blur-sm rounded-lg">
                  <span className="text-xs font-semibold text-[#1a1a1a] uppercase tracking-wide">Case Study</span>
                </div>
              </div>
            </div>

            {/* Right - Content */}
            <div className="p-10 lg:p-14">
              <h3 
                className="text-2xl lg:text-3xl font-light text-[#1a1a1a] mb-8 leading-snug"
                style={{ fontFamily: "var(--font-serif)" }}
              >
                How a startup went from{" "}
                <span className="italic">zero outbound pipeline to 15+ qualified demos per month</span>{" "}
                in 30 days
              </h3>

              {/* Metrics */}
              <div className="grid grid-cols-2 gap-6 mb-8">
                <motion.div
                  initial={{ opacity: 0, scale: 0.9 }}
                  whileInView={{ opacity: 1, scale: 1 }}
                  viewport={{ once: true }}
                  className="bg-[#E85D04] rounded-2xl p-6 text-white"
                >
                  <p className="text-4xl lg:text-5xl font-light mb-2">340%</p>
                  <p className="text-sm opacity-80">Pipeline increase in 60 days</p>
                </motion.div>
                <motion.div
                  initial={{ opacity: 0, scale: 0.9 }}
                  whileInView={{ opacity: 1, scale: 1 }}
                  viewport={{ once: true }}
                  transition={{ delay: 0.1 }}
                  className="bg-[#F8F7F4] rounded-2xl p-6"
                >
                  <p className="text-4xl lg:text-5xl font-light text-[#E85D04] mb-2">15+</p>
                  <p className="text-sm text-[#666]">Qualified demos booked monthly</p>
                </motion.div>
                <motion.div
                  initial={{ opacity: 0, scale: 0.9 }}
                  whileInView={{ opacity: 1, scale: 1 }}
                  viewport={{ once: true }}
                  transition={{ delay: 0.2 }}
                  className="bg-[#F8F7F4] rounded-2xl p-6"
                >
                  <p className="text-4xl lg:text-5xl font-light text-[#E85D04] mb-2">92%</p>
                  <p className="text-sm text-[#666]">Email deliverability rate</p>
                </motion.div>
                <motion.div
                  initial={{ opacity: 0, scale: 0.9 }}
                  whileInView={{ opacity: 1, scale: 1 }}
                  viewport={{ once: true }}
                  transition={{ delay: 0.3 }}
                  className="bg-[#F8F7F4] rounded-2xl p-6"
                >
                  <p className="text-4xl lg:text-5xl font-light text-[#E85D04] mb-2">$0</p>
                  <p className="text-sm text-[#666]">Paid until results delivered</p>
                </motion.div>
              </div>

              <p className="text-[#666] italic">
                "Advan AI completely transformed our outbound. We went from struggling to book a single demo to having a predictable pipeline that fuels our Series A growth. The ROI has been incredible."
              </p>
            </div>
          </div>
        </motion.div>

        {/* Secondary Metrics Cards */}
        <div className="grid md:grid-cols-2 gap-6">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="bg-white rounded-2xl p-8 flex items-center gap-8"
          >
            <div className="w-20 h-20 rounded-full bg-[#E85D04]/10 flex items-center justify-center flex-shrink-0">
              <span className="text-2xl font-light text-[#E85D04]">10K+</span>
            </div>
            <div>
              <p className="text-2xl font-light text-[#1a1a1a] mb-1" style={{ fontFamily: "var(--font-serif)" }}>
                Verified prospects per campaign
              </p>
              <p className="text-sm text-[#666]">ICP-matched, email-verified, and enriched with intent signals</p>
            </div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: 0.1 }}
            className="bg-white rounded-2xl p-8 flex items-center gap-8"
          >
            <div className="w-20 h-20 rounded-full bg-[#E85D04]/10 flex items-center justify-center flex-shrink-0">
              <span className="text-2xl font-light text-[#E85D04]">65%</span>
            </div>
            <div>
              <p className="text-2xl font-light text-[#1a1a1a] mb-1" style={{ fontFamily: "var(--font-serif)" }}>
                Lower cost per qualified meeting
              </p>
              <p className="text-sm text-[#666]">Compared to traditional SDR teams or lead gen agencies</p>
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  )
}
