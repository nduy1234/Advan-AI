"use client"

import { useEffect, useState, useRef } from "react"
import Link from "next/link"
import Image from "next/image"
import { motion, useMotionValue, useTransform, useSpring, AnimatePresence } from "framer-motion"
import { Button } from "@/components/ui/button"
import { ArrowRight } from "lucide-react"

const BOOKING_URL = "https://cal.com/day-nguyen"

const ROTATING_PHRASES = [
  "Predictable Revenue",
]

const CARDS = [
  { id: 1, image: "/card-profile.jpg", label: "Adam Jones", sublabel: "VP of Sales · Fintech" },
  { id: 2, image: "/card-demo.jpg", label: "Demo Booked", sublabel: "Today, 2:00 PM" },
  { id: 3, image: "/card-lead.jpg", label: "Qualified Lead", sublabel: "High intent signal" },
  { id: 4, image: "/card-sequence.jpg", label: "AI Sequence Active", sublabel: "Step 3 of 5 · 12 prospects" },
  { id: 5, image: "/card-reply.jpg", label: "Reply Received", sublabel: "38% reply rate this week" },
  { id: 6, image: "/card-email.jpg", label: "james@healthsaas.com", sublabel: "Opened · 2 min ago" },
]

function StackedCards() {
  const [order, setOrder] = useState(CARDS.map((_, i) => i))
  const [hoveredIdx, setHoveredIdx] = useState<number | null>(null)

  useEffect(() => {
    const interval = setInterval(() => {
      setOrder((prev) => {
        const next = [...prev]
        const last = next.pop()!
        next.unshift(last)
        return next
      })
    }, 2500)
    return () => clearInterval(interval)
  }, [])

  return (
    <div className="relative w-[290px] h-[370px] select-none" aria-hidden="true">
      {order.map((cardIdx, stackPos) => {
        const card = CARDS[cardIdx]
        const total = order.length
        const isTop = stackPos === total - 1

        const xOffset = (total - 1 - stackPos) * 12
        const yOffset = (total - 1 - stackPos) * 5
        const scale = 1 - (total - 1 - stackPos) * 0.04
        const zIndex = stackPos

        return (
          <motion.div
            key={card.id}
            layout
            animate={{ x: xOffset, y: yOffset, scale, zIndex }}
            whileHover={isTop ? { scale: scale * 1.02, y: yOffset - 4 } : {}}
            transition={{ type: "spring", stiffness: 280, damping: 28 }}
            onHoverStart={() => isTop && setHoveredIdx(cardIdx)}
            onHoverEnd={() => setHoveredIdx(null)}
            className="absolute inset-0 rounded-2xl overflow-hidden shadow-2xl cursor-pointer bg-[#111]"
            style={{ boxShadow: isTop ? "0 25px 60px rgba(0,0,0,0.6), 0 0 0 1px rgba(255,255,255,0.08)" : undefined }}
          >
            <div className="relative w-full h-full">
              <Image
                src={card.image}
                alt={card.label}
                fill
                className="object-cover"
                sizes="290px"
                priority={isTop}
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/85 via-black/20 to-transparent" />
              {/* Top gloss line */}
              <div className="absolute top-0 left-0 right-0 h-px bg-gradient-to-r from-transparent via-white/20 to-transparent" />
              <div className="absolute bottom-0 left-0 right-0 px-5 py-4">
                <p className="text-white font-semibold text-sm leading-tight">{card.label}</p>
                <p className="text-white/55 text-xs mt-0.5">{card.sublabel}</p>
              </div>
            </div>
          </motion.div>
        )
      })}
    </div>
  )
}

export function HeroSection() {
  const sectionRef = useRef<HTMLElement>(null)
  const scrollY = useMotionValue(0)
  const [phraseIdx, setPhraseIdx] = useState(0)

  const mouseX = useMotionValue(0.5)
  const mouseY = useMotionValue(0.5)
  const glowX = useSpring(useTransform(mouseX, [0, 1], ["-10%", "110%"]), { stiffness: 40, damping: 20 })
  const glowY = useSpring(useTransform(mouseY, [0, 1], ["-10%", "110%"]), { stiffness: 40, damping: 20 })

  useEffect(() => {
    const handleScroll = () => scrollY.set(window.scrollY)
    window.addEventListener("scroll", handleScroll, { passive: true })
    return () => window.removeEventListener("scroll", handleScroll)
  }, [scrollY])

  useEffect(() => {
    const iv = setInterval(() => setPhraseIdx(i => (i + 1) % ROTATING_PHRASES.length), 2800)
    return () => clearInterval(iv)
  }, [])

  const handleMouseMove = (e: React.MouseEvent) => {
    const rect = sectionRef.current?.getBoundingClientRect()
    if (!rect) return
    mouseX.set((e.clientX - rect.left) / rect.width)
    mouseY.set((e.clientY - rect.top) / rect.height)
  }

  const opacity = useTransform(scrollY, [0, 500], [1, 0])
  const y = useTransform(scrollY, [0, 700], [0, 70])

  return (
    <section
      ref={sectionRef}
      className="relative min-h-[60vh] overflow-hidden bg-[#080808]"
      onMouseMove={handleMouseMove}
    >
      {/* Dot grid background */}
      <div className="absolute inset-0 pointer-events-none"
        style={{
          backgroundImage: "radial-gradient(circle, rgba(255,255,255,0.07) 1px, transparent 1px)",
          backgroundSize: "32px 32px",
        }}
      />

      {/* Mouse-following glow */}
      <motion.div
        className="absolute w-[600px] h-[600px] rounded-full pointer-events-none"
        style={{
          left: glowX,
          top: glowY,
          x: "-50%",
          y: "-50%",
          background: "radial-gradient(circle, rgba(124,58,237,0.18) 0%, transparent 70%)",
        }}
      />

      {/* Static ambient glows */}
      <div className="absolute inset-0 pointer-events-none"
        style={{
          background: "radial-gradient(ellipse 60% 50% at 80% 50%, rgba(139,92,246,0.10) 0%, transparent 70%), radial-gradient(ellipse 40% 40% at 15% 70%, rgba(59,130,246,0.07) 0%, transparent 60%)",
        }}
      />

      {/* Top border line */}
      <div className="absolute top-0 left-0 right-0 h-px bg-gradient-to-r from-transparent via-white/10 to-transparent" />

      <motion.div style={{ opacity, y }} className="relative z-10 flex items-center min-h-[60vh] pb-8 pt-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 w-full">
          <div className="flex flex-col lg:flex-row items-center justify-between gap-12">

            {/* Left */}
            <div className="flex-1 max-w-2xl">
              {/* Headline */}
              <motion.h1
                initial={{ opacity: 0, y: 50 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.9, delay: 0.4, ease: [0.25, 0.1, 0.25, 1] }}
                className="text-[45px] font-light text-white leading-[1.05] tracking-tight"
              >
                <span className="block">AI-Powered</span>
                <span className="block">Growth Systems for</span>
                <span className="block h-[1.15em] relative overflow-hidden">
                  <AnimatePresence mode="wait">
                    <motion.span
                      key={phraseIdx}
                      initial={{ y: "100%", opacity: 0 }}
                      animate={{ y: 0, opacity: 1 }}
                      exit={{ y: "-100%", opacity: 0 }}
                      transition={{ duration: 0.5, ease: [0.25, 0.1, 0.25, 1] }}
                      className="block italic text-[#a78bfa] absolute inset-0"
                    >
                      {ROTATING_PHRASES[phraseIdx]}
                    </motion.span>
                  </AnimatePresence>
                </span>
              </motion.h1>

              <motion.p
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.8, delay: 0.9 }}
                className="mt-8 text-lg text-white/55 max-w-xl leading-relaxed"
              >
                Build, optimize, and scale AI agents that generate new demand, reactivate existing leads, and convert inbound traffic.
              </motion.p>

              {/* CTAs */}
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.8, delay: 1.1 }}
                className="mt-8 flex flex-col sm:flex-row gap-4"
              >
                <Button size="lg" asChild
                  className="relative group bg-[#7c3aed] hover:bg-[#6d28d9] text-white rounded-full px-8 h-13 text-base overflow-hidden shadow-xl shadow-purple-900/40"
                >
                  <Link href={BOOKING_URL} target="_blank" rel="noopener noreferrer">
                    <span className="relative z-10 flex items-center gap-2">
                      Book a demo
                      <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
                    </span>
                    <motion.div
                      className="absolute inset-0 bg-gradient-to-r from-[#9333ea] to-[#7c3aed] opacity-0 group-hover:opacity-100 transition-opacity"
                    />
                  </Link>
                </Button>
                <Button size="lg" variant="outline" asChild
                  className="border-white/15 text-white hover:bg-white/8 hover:border-white/25 rounded-full px-8 h-13 text-base bg-transparent transition-all"
                >
                  <Link href="/#platform">See how it works</Link>
                </Button>
              </motion.div>

            </div>

            {/* Right: cards + floating badges */}
            <motion.div
              initial={{ opacity: 0, x: 50 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 1, delay: 0.6, ease: [0.25, 0.1, 0.25, 1] }}
              className="hidden lg:flex flex-1 items-center justify-center"
            >
              <div className="relative">
                {/* Glow behind cards */}
                <div className="absolute inset-0 scale-110 rounded-3xl blur-3xl bg-purple-500/10 pointer-events-none" />

                <StackedCards />

              </div>
            </motion.div>

          </div>
        </div>
      </motion.div>
    </section>
  )
}
