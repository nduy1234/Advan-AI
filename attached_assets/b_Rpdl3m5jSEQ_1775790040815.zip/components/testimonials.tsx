"use client"

import { motion } from "framer-motion"

const testimonials = [
  {
    quote: "Motio has completely transformed how our design team approaches animations. What used to take hours now takes minutes.",
    author: "Sarah Chen",
    role: "Design Lead at Vercel",
  },
  {
    quote: "The intuitive interface and powerful features make it the perfect tool for both beginners and advanced animators.",
    author: "Marcus Rodriguez",
    role: "Creative Director at Linear",
  },
  {
    quote: "We shipped our entire product launch animation suite in just two days. Absolutely incredible tool.",
    author: "Emily Watson",
    role: "Brand Designer at Notion",
  },
]

export function Testimonials() {
  return (
    <section id="customers" className="py-24 px-6 bg-accent/30">
      <div className="max-w-6xl mx-auto">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="text-center mb-16"
        >
          <h2 className="text-3xl md:text-5xl font-bold text-foreground mb-4 text-balance">
            Loved by creative teams
          </h2>
          <p className="text-lg text-muted-foreground">
            See what designers and teams are saying about Motio.
          </p>
        </motion.div>

        <div className="grid md:grid-cols-3 gap-6">
          {testimonials.map((testimonial, index) => (
            <motion.div
              key={testimonial.author}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: index * 0.15 }}
              className="p-8 rounded-2xl bg-background border border-border"
            >
              <p className="text-foreground leading-relaxed mb-6 text-pretty">
                &ldquo;{testimonial.quote}&rdquo;
              </p>
              <div>
                <p className="font-semibold text-foreground">
                  {testimonial.author}
                </p>
                <p className="text-sm text-muted-foreground">
                  {testimonial.role}
                </p>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  )
}
