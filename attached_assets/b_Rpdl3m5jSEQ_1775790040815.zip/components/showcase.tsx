"use client"

import { useEffect, useRef, useState } from "react"
import { motion, useMotionValue, useTransform } from "framer-motion"

export function Showcase() {
  const containerRef = useRef<HTMLDivElement>(null)
  const scrollY = useMotionValue(0)
  const [offsetTop, setOffsetTop] = useState(0)

  useEffect(() => {
    const updateOffset = () => {
      if (containerRef.current) {
        setOffsetTop(containerRef.current.offsetTop)
      }
    }
    updateOffset()
    window.addEventListener("resize", updateOffset)
    return () => window.removeEventListener("resize", updateOffset)
  }, [])

  useEffect(() => {
    const handleScroll = () => scrollY.set(window.scrollY)
    window.addEventListener("scroll", handleScroll, { passive: true })
    return () => window.removeEventListener("scroll", handleScroll)
  }, [scrollY])

  const y = useTransform(scrollY, [offsetTop - 400, offsetTop + 400], [100, -100])
  const opacity = useTransform(scrollY, [offsetTop - 600, offsetTop - 200, offsetTop + 200, offsetTop + 600], [0, 1, 1, 0])

  return (
    <section ref={containerRef} className="relative py-24 px-6 overflow-hidden">
      <div className="max-w-6xl mx-auto">
        <motion.div
          style={{ y, opacity }}
          className="relative aspect-video rounded-2xl bg-gradient-to-br from-accent to-secondary border border-border overflow-hidden"
        >
          <div className="absolute inset-0 flex items-center justify-center">
            <motion.div
              initial={{ scale: 0.8, opacity: 0 }}
              whileInView={{ scale: 1, opacity: 1 }}
              viewport={{ once: true }}
              transition={{ duration: 0.8, ease: "easeOut" }}
              className="text-center"
            >
              <div className="grid grid-cols-3 gap-4 p-8">
                {[...Array(9)].map((_, i) => (
                  <motion.div
                    key={i}
                    initial={{ opacity: 0, scale: 0.5 }}
                    whileInView={{ opacity: 1, scale: 1 }}
                    viewport={{ once: true }}
                    transition={{ duration: 0.4, delay: i * 0.1 }}
                    whileHover={{ scale: 1.1, rotate: 5 }}
                    className="w-16 h-16 md:w-24 md:h-24 rounded-xl bg-background border border-border shadow-lg"
                  />
                ))}
              </div>
            </motion.div>
          </div>
        </motion.div>
      </div>
    </section>
  )
}
