"use client"

import { useState, useEffect, useRef } from "react"
import { motion, AnimatePresence } from "framer-motion"
import Link from "next/link"
import { CheckCircle2 } from "lucide-react"

const features = [
  {
    number: "01",
    title: "AI Outbound",
    description: "Generate predictable pipeline on autopilot. We source ideal prospects, personalize outreach with AI, manage deliverability, and book qualified meetings directly to your calendar.",
    result: "Fill your pipeline with qualified leads.",
    color: "#E85D04",
    items: [
      "ICP-based lead sourcing",
      "AI-personalized email sequences",
      "Automated follow-ups",
      "Qualified meetings booked for your team",
    ],
  },
  {
    number: "02",
    title: "AI Reactivation",
    description: "Unlock revenue already in your database. We identify dormant leads and past opportunities, re-engage them with AI-driven campaigns, and route interested prospects back to sales.",
    result: "Monetize your existing database with intelligent re-engagement.",
    color: "#7c3aed",
    items: [
      "Database segmentation & scoring",
      "AI re-engagement campaigns",
      "Multi-touch follow-up automation",
      "Qualification & meeting routing",
    ],
  },
  {
    number: "03",
    title: "AI Conversion",
    description: "Turn website traffic into booked meetings. We qualify visitors in real time, automate follow-up, and drive high-intent prospects directly into your calendar.",
    result: "Capture and convert inbound demand automatically.",
    color: "#059669",
    items: [
      "Real-time visitor qualification",
      "AI chat & booking assistant",
      "Automated meeting scheduling",
      "CRM tagging & routing",
    ],
  },
]

const DURATION = 4500

export function NewStandardSection() {
  const [active, setActive] = useState(0)
  const [paused, setPaused] = useState(false)
  const [progress, setProgress] = useState(0)
  const intervalRef = useRef<ReturnType<typeof setInterval> | null>(null)
  const progressRef = useRef<ReturnType<typeof setInterval> | null>(null)

  const startTimers = () => {
    setProgress(0)
    clearInterval(intervalRef.current!)
    clearInterval(progressRef.current!)

    const startTime = Date.now()
    progressRef.current = setInterval(() => {
      const elapsed = Date.now() - startTime
      setProgress(Math.min((elapsed / DURATION) * 100, 100))
    }, 30)

    intervalRef.current = setInterval(() => {
      setActive(prev => (prev + 1) % features.length)
    }, DURATION)
  }

  useEffect(() => {
    if (!paused) startTimers()
    return () => {
      clearInterval(intervalRef.current!)
      clearInterval(progressRef.current!)
    }
  }, [paused, active])

  const handleTabClick = (i: number) => {
    setActive(i)
    startTimers()
  }

  const current = features[active]

  return (
    <section
      id="platform"
      className="py-12 lg:py-20 bg-white relative overflow-hidden"
      aria-labelledby="platform-heading"
      onMouseEnter={() => setPaused(true)}
      onMouseLeave={() => setPaused(false)}
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">

        {/* Header */}
        <div className="max-w-4xl mb-10">
          <motion.p
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-sm font-semibold text-[#E85D04] uppercase tracking-wider mb-4"
          >
            A New Standard for B2B Revenue Growth
          </motion.p>
          <motion.h2
            id="platform-heading"
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: 0.1 }}
            className="text-xl md:text-2xl lg:text-3xl font-light text-[#1a1a1a] leading-[1.2] mb-6 text-balance"
            style={{ fontFamily: "var(--font-serif)" }}
          >
            A fully managed AI Growth Engine that delivers qualified sales meetings and predictable B2B pipeline.
          </motion.h2>
          <motion.div
            initial={{ opacity: 0, y: 10 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: 0.2 }}
          >
            <Link
              href="/#lifecycle"
              className="inline-flex items-center gap-2 text-[#E85D04] font-medium hover:underline underline-offset-4 transition-all"
            >
              <span>How the AI Growth Engine works</span>
              <motion.span animate={{ x: [0, 4, 0] }} transition={{ duration: 1.5, repeat: Infinity }}>
                →
              </motion.span>
            </Link>
          </motion.div>
        </div>

        {/* Interactive panel */}
        <div className="grid grid-cols-1 lg:grid-cols-[280px_1fr] gap-4 lg:gap-8">

          {/* Left: Tab selectors */}
          <div className="flex flex-row lg:flex-col gap-2 overflow-x-auto lg:overflow-visible pb-2 lg:pb-0">
            {features.map((f, i) => {
              const isActive = active === i
              return (
                <button
                  key={f.number}
                  onClick={() => handleTabClick(i)}
                  className={`relative flex-shrink-0 text-left rounded-2xl p-4 lg:p-5 transition-all duration-300 border ${
                    isActive
                      ? "bg-[#1a1a1a] border-[#1a1a1a]"
                      : "bg-[#f8f6f3] border-[#e8e5e0] hover:border-[#ccc] hover:bg-[#f0ede8]"
                  }`}
                >
                  <div className="flex items-center gap-3 mb-1">
                    <span
                      className={`text-xs font-bold tabular-nums ${isActive ? "text-white/50" : "text-[#aaa]"}`}
                    >
                      {f.number}
                    </span>
                    <span
                      className={`text-base font-semibold ${isActive ? "text-white" : "text-[#1a1a1a]"}`}
                    >
                      {f.title}
                    </span>
                  </div>

                  {/* Progress bar (only on active) */}
                  {isActive && (
                    <div className="mt-3 h-0.5 w-full bg-white/20 rounded-full overflow-hidden">
                      <motion.div
                        className="h-full rounded-full"
                        style={{ backgroundColor: f.color, width: `${progress}%` }}
                      />
                    </div>
                  )}
                </button>
              )
            })}
          </div>

          {/* Right: Content panel */}
          <div className="relative rounded-3xl bg-[#f8f6f3] border border-[#e8e5e0] overflow-hidden min-h-[380px]">

            {/* Decorative number */}
            <div
              className="absolute top-4 right-6 text-[120px] lg:text-[160px] font-bold leading-none select-none pointer-events-none"
              style={{ color: `${current.color}08` }}
            >
              {current.number}
            </div>

            <AnimatePresence mode="wait">
              <motion.div
                key={active}
                initial={{ opacity: 0, y: 24 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -16 }}
                transition={{ duration: 0.35, ease: [0.25, 0.1, 0.25, 1] }}
                className="relative z-10 p-8 lg:p-12"
              >
                {/* Colour accent */}
                <div
                  className="inline-flex items-center gap-2 px-3 py-1 rounded-full text-xs font-semibold mb-6"
                  style={{ backgroundColor: `${current.color}15`, color: current.color }}
                >
                  <span className="w-1.5 h-1.5 rounded-full inline-block" style={{ backgroundColor: current.color }} />
                  {current.title}
                </div>

                <h3
                  className="text-2xl lg:text-4xl font-light text-[#1a1a1a] mb-4 leading-tight"
                  style={{ fontFamily: "var(--font-serif)" }}
                >
                  {current.description}
                </h3>

                <div
                  className="inline-block text-sm font-medium px-4 py-2 rounded-xl mb-8"
                  style={{ backgroundColor: `${current.color}12`, color: current.color }}
                >
                  <span className="font-bold">Result:</span> {current.result}
                </div>

                <ul className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  {current.items.map((item, i) => (
                    <motion.li
                      key={item}
                      initial={{ opacity: 0, x: -8 }}
                      animate={{ opacity: 1, x: 0 }}
                      transition={{ delay: i * 0.07, duration: 0.3 }}
                      className="flex items-center gap-3 bg-white rounded-xl px-4 py-3 shadow-sm border border-[#ece9e4]"
                    >
                      <CheckCircle2
                        className="w-4 h-4 flex-shrink-0"
                        strokeWidth={2}
                        style={{ color: current.color }}
                      />
                      <span className="text-sm text-[#1a1a1a] font-medium">{item}</span>
                    </motion.li>
                  ))}
                </ul>
              </motion.div>
            </AnimatePresence>
          </div>
        </div>

      </div>
    </section>
  )
}
