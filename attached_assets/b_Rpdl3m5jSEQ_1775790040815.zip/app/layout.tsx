import React from "react"
import type { Metadata } from 'next'
import { Inter, Playfair_Display } from 'next/font/google'
import { Analytics } from '@vercel/analytics/next'
import './globals.css'

const inter = Inter({ 
  subsets: ["latin"],
  variable: '--font-sans'
});

const playfair = Playfair_Display({
  subsets: ["latin"],
  variable: '--font-serif',
  style: ['normal', 'italic']
});

const SITE_URL = 'https://advanai.net'

export const metadata: Metadata = {
  title: {
    default: 'Advan AI — AI-Powered Growth Systems for Predictable B2B Revenue',
    template: '%s | Advan AI'
  },
  description: 'Advan AI builds fully managed AI Growth Engines that deliver qualified B2B sales meetings through AI outbound prospecting, CRM reactivation, and real-time inbound conversion. First results in 2–3 weeks.',
  keywords: [
    'AI sales automation',
    'AI outbound prospecting',
    'B2B lead generation',
    'AI Growth Engine',
    'qualified sales meetings',
    'pipeline generation',
    'CRM reactivation',
    'AI revenue system',
    'outbound sales automation',
    'predictable revenue',
    'B2B pipeline',
    'sales appointment setting',
  ],
  authors: [{ name: 'Advan AI', url: SITE_URL }],
  creator: 'Advan AI',
  publisher: 'Advan AI',
  metadataBase: new URL(SITE_URL),
  alternates: {
    canonical: SITE_URL,
  },
  openGraph: {
    type: 'website',
    locale: 'en_US',
    url: SITE_URL,
    siteName: 'Advan AI',
    title: 'Advan AI — AI-Powered Growth Systems for Predictable B2B Revenue',
    description: 'Fully managed AI Growth Engines that deliver qualified B2B sales meetings through AI outbound, CRM reactivation, and inbound conversion. Results in 2–3 weeks.',
    images: [
      {
        url: '/og-image.jpg',
        width: 1200,
        height: 630,
        alt: 'Advan AI — AI-Powered Growth Systems for Predictable Revenue',
      },
    ],
  },
  twitter: {
    card: 'summary_large_image',
    title: 'Advan AI — AI-Powered Growth Systems for Predictable B2B Revenue',
    description: 'Fully managed AI Growth Engines that deliver qualified sales meetings through AI outbound, CRM reactivation, and real-time inbound conversion.',
    images: ['/og-image.jpg'],
  },
  robots: {
    index: true,
    follow: true,
    googleBot: {
      index: true,
      follow: true,
      'max-video-preview': -1,
      'max-image-preview': 'large',
      'max-snippet': -1,
    },
  },
  icons: {
    icon: [
      { url: '/favicon.png', type: 'image/png' },
    ],
    apple: '/apple-touch-icon.png',
  },
}

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode
}>) {
  return (
    <html lang="en" data-scroll-behavior="smooth">
      <body className={`${inter.variable} ${playfair.variable} font-sans antialiased`}>
        {children}
        <Analytics />
      </body>
    </html>
  )
}
