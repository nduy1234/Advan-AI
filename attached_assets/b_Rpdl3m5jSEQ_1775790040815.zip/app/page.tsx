import { HeroSection } from "@/components/hero-section"
import { NewStandardSection } from "@/components/new-standard-section"
import { LifecycleSection } from "@/components/lifecycle-section"
import { SuccessStories } from "@/components/success-stories"
import { ComplianceSection } from "@/components/compliance-section"
import { FinalCTA } from "@/components/final-cta"
import { FAQSection } from "@/components/faq-section"
import { ContactSection } from "@/components/contact-section"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { StructuredData } from "@/app/structured-data"

export default function Page() {
  return (
    <>
      <StructuredData />

      {/* Navigation */}
      <Header />
      
      <main>
        {/* Hero: AI Growth Engine for predictable B2B revenue */}
        <HeroSection />

        {/* Platform: AI Outbound, Reactivation, Conversion */}
        <NewStandardSection />

        {/* AI Growth Engine Lifecycle */}
        <LifecycleSection />

        {/* Proven Results & Case Studies */}
        <SuccessStories />

        {/* Security & Compliance */}
        <ComplianceSection />

        {/* Book a Demo CTA */}
        <FinalCTA />

        {/* FAQ */}
        <FAQSection />

        {/* Contact */}
        <ContactSection />
      </main>

      <Footer />
    </>
  )
}
