const SITE_URL = "https://advanai.net"

const faqs = [
  {
    question: "What is Advan AI?",
    answer: "Advan AI is a fully managed AI-powered revenue growth service that builds, deploys, and optimizes AI Growth Engines for B2B companies. It handles the entire pipeline — from ICP research and prospect sourcing to personalized outreach, qualification, and booked sales meetings — so clients receive qualified demos without managing any outbound infrastructure themselves."
  },
  {
    question: "What is an AI Growth Engine?",
    answer: "An AI Growth Engine is a fully automated, end-to-end revenue system that combines AI outbound prospecting, CRM reactivation, and real-time inbound conversion. Advan AI's AI Growth Engine sources 10,000+ verified prospects per campaign, personalizes every touchpoint using AI, manages email deliverability, and routes qualified leads to sales calendars — operating continuously without manual SDR involvement."
  },
  {
    question: "How does Advan AI generate qualified sales meetings?",
    answer: "Advan AI generates qualified sales meetings through a four-phase lifecycle: (1) Design — defining the ideal customer profile and building a verified prospect database; (2) Test — A/B testing messaging sequences to identify what converts; (3) Scale — deploying high-performing sequences to thousands of prospects with AI personalization; (4) Optimize — continuously refining targeting and messaging based on real engagement data. Most clients book their first qualified meeting within 2–3 weeks of launch."
  },
  {
    question: "Who is Advan AI built for?",
    answer: "Advan AI is designed for B2B companies at any stage — pre-revenue startups building their first outbound pipeline, growth-stage companies scaling alongside inbound, and established businesses seeking efficient customer acquisition. The AI Growth Engine adapts to each client's specific ideal customer profile, market, and revenue goals."
  },
  {
    question: "What makes Advan AI unique?",
    answer: "Traditional SDRs cost $60,000–$80,000+ per year in salary, benefits, tools, and management overhead, and take 3–6 months to ramp. Lead generation agencies typically deliver unqualified leads with generic templates and no campaign ownership. Advan AI combines AI precision with human-quality output at 65% lower cost per qualified meeting, with results typically visible within 2–3 weeks rather than months."
  },
  {
    question: "How long does it take to see the first results from Advan AI?",
    answer: "Most clients receive their first qualified appointments within 2–3 weeks of engagement. Week 1 is dedicated to building the custom AI Growth Engine — ICP mapping, prospect research, messaging development, and technical infrastructure setup. Weeks 2–3 initiate outreach and meeting booking. Results compound over time as the AI system learns which messages and segments perform best for that specific market."
  },
  {
    question: "Does Advan AI require day-to-day involvement from my team?",
    answer: "No. Advan AI is a fully managed, done-for-you service. The team handles all technical setup, prospect research, content creation, campaign management, deliverability monitoring, and meeting scheduling. Clients attend a brief weekly strategy call and show up to the demos booked on their behalf."
  },
  {
    question: "Is Advan AI compliant with data privacy regulations?",
    answer: "Yes. Advan AI's infrastructure is designed with enterprise-grade security and compliance in mind, including alignment with GDPR (EU data privacy), CCPA (California privacy), and email deliverability best practices including SPF, DKIM, and DMARC authentication. All prospect data is sourced through compliant, permission-based data providers."
  }
]

export function StructuredData() {
  const organizationSchema = {
    "@context": "https://schema.org",
    "@type": "Organization",
    "@id": `${SITE_URL}/#organization`,
    "name": "Advan AI",
    "url": SITE_URL,
    "logo": {
      "@type": "ImageObject",
      "url": `${SITE_URL}/favicon.png`
    },
    "description": "Advan AI delivers fully managed AI-powered revenue growth systems for B2B companies, generating predictable sales pipeline through AI outbound, CRM reactivation, and inbound conversion.",
    "sameAs": [],
    "contactPoint": {
      "@type": "ContactPoint",
      "contactType": "sales",
      "url": "https://cal.com/day-nguyen"
    }
  }

  const websiteSchema = {
    "@context": "https://schema.org",
    "@type": "WebSite",
    "@id": `${SITE_URL}/#website`,
    "url": SITE_URL,
    "name": "Advan AI",
    "publisher": { "@id": `${SITE_URL}/#organization` }
  }

  const webPageSchema = {
    "@context": "https://schema.org",
    "@type": "WebPage",
    "@id": `${SITE_URL}/#webpage`,
    "url": SITE_URL,
    "name": "Advan AI — AI-Powered Growth Systems for Predictable Revenue",
    "description": "Advan AI builds fully managed AI Growth Engines that deliver qualified B2B sales meetings through AI outbound prospecting, CRM reactivation, and real-time inbound conversion.",
    "isPartOf": { "@id": `${SITE_URL}/#website` },
    "about": { "@id": `${SITE_URL}/#organization` },
    "breadcrumb": {
      "@type": "BreadcrumbList",
      "itemListElement": [
        { "@type": "ListItem", "position": 1, "name": "Home", "item": SITE_URL }
      ]
    }
  }

  const serviceSchema = {
    "@context": "https://schema.org",
    "@type": "Service",
    "serviceType": "AI-Powered B2B Revenue Growth",
    "provider": { "@id": `${SITE_URL}/#organization` },
    "name": "AI Growth Engine",
    "description": "A fully managed AI revenue system that sources verified B2B prospects, runs personalized outreach campaigns, reactivates dormant CRM leads, and converts inbound traffic into qualified sales meetings.",
    "hasOfferCatalog": {
      "@type": "OfferCatalog",
      "name": "AI Growth Services",
      "itemListElement": [
        {
          "@type": "Offer",
          "itemOffered": {
            "@type": "Service",
            "name": "AI Outbound",
            "description": "ICP-based prospect sourcing, AI-personalized email sequences, automated follow-ups, and qualified meeting booking."
          }
        },
        {
          "@type": "Offer",
          "itemOffered": {
            "@type": "Service",
            "name": "AI Reactivation",
            "description": "Database segmentation, AI re-engagement campaigns for dormant leads, and multi-touch follow-up automation."
          }
        },
        {
          "@type": "Offer",
          "itemOffered": {
            "@type": "Service",
            "name": "AI Conversion",
            "description": "Real-time visitor qualification, AI chat and booking assistant, and automated inbound meeting scheduling."
          }
        }
      ]
    }
  }

  const faqSchema = {
    "@context": "https://schema.org",
    "@type": "FAQPage",
    "mainEntity": faqs.map(faq => ({
      "@type": "Question",
      "name": faq.question,
      "acceptedAnswer": {
        "@type": "Answer",
        "text": faq.answer
      }
    }))
  }

  return (
    <>
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(organizationSchema) }}
      />
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(websiteSchema) }}
      />
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(webPageSchema) }}
      />
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(serviceSchema) }}
      />
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(faqSchema) }}
      />
    </>
  )
}

export { faqs }
