import { Header } from "@/components/header"
import { Footer } from "@/components/footer"

export default function TermsOfServicePage() {
  return (
    <>
      <Header />
      <main className="pt-20">
        <section className="py-24 bg-background">
          <div className="container mx-auto px-6">
            <div className="max-w-3xl mx-auto">
              <h1 className="text-4xl font-bold text-primary mb-8">Terms of Service</h1>
              <p className="text-muted-foreground mb-8">Last updated: January 2026</p>

              <div className="prose prose-lg max-w-none space-y-8">
                <section>
                  <h2 className="text-2xl font-bold text-foreground mb-4">Agreement to Terms</h2>
                  <p className="text-muted-foreground leading-relaxed">
                    By accessing or using Advan AI's services, you agree to be bound by these Terms of Service and all applicable laws and regulations. If you do not agree with any of these terms, you are prohibited from using or accessing our services.
                  </p>
                </section>

                <section>
                  <h2 className="text-2xl font-bold text-foreground mb-4">Description of Services</h2>
                  <p className="text-muted-foreground leading-relaxed">
                    Advan AI provides AI-powered growth systems designed to generate predictable, scalable company growth. Our services include lead generation, automated outreach, CRM integration, and performance analytics. Service specifics are outlined in your individual service agreement.
                  </p>
                </section>

                <section>
                  <h2 className="text-2xl font-bold text-foreground mb-4">User Responsibilities</h2>
                  <p className="text-muted-foreground leading-relaxed mb-4">
                    As a user of our services, you agree to:
                  </p>
                  <ul className="list-disc pl-6 space-y-2 text-muted-foreground">
                    <li>Provide accurate and complete information</li>
                    <li>Maintain the security of your account credentials</li>
                    <li>Use our services in compliance with all applicable laws</li>
                    <li>Not use our services for any unlawful or prohibited purpose</li>
                    <li>Not interfere with or disrupt our services or servers</li>
                  </ul>
                </section>

                <section>
                  <h2 className="text-2xl font-bold text-foreground mb-4">Intellectual Property</h2>
                  <p className="text-muted-foreground leading-relaxed">
                    All content, features, and functionality of our services, including but not limited to text, graphics, logos, and software, are owned by Advan AI and are protected by copyright, trademark, and other intellectual property laws. You may not reproduce, distribute, or create derivative works without our express written permission.
                  </p>
                </section>

                <section>
                  <h2 className="text-2xl font-bold text-foreground mb-4">Payment Terms</h2>
                  <p className="text-muted-foreground leading-relaxed">
                    Payment terms are specified in your service agreement. All fees are non-refundable unless otherwise stated. We reserve the right to modify our pricing with 30 days' notice. Failure to pay may result in suspension or termination of services.
                  </p>
                </section>

                <section>
                  <h2 className="text-2xl font-bold text-foreground mb-4">Service Guarantees</h2>
                  <p className="text-muted-foreground leading-relaxed">
                    Performance guarantees, including minimum appointment targets, are subject to the terms outlined in your specific service agreement. Results may vary based on factors including but not limited to your industry, target market, and offer positioning.
                  </p>
                </section>

                <section>
                  <h2 className="text-2xl font-bold text-foreground mb-4">Limitation of Liability</h2>
                  <p className="text-muted-foreground leading-relaxed">
                    To the maximum extent permitted by law, Advan AI shall not be liable for any indirect, incidental, special, consequential, or punitive damages, or any loss of profits or revenues, whether incurred directly or indirectly, or any loss of data, use, goodwill, or other intangible losses.
                  </p>
                </section>

                <section>
                  <h2 className="text-2xl font-bold text-foreground mb-4">Termination</h2>
                  <p className="text-muted-foreground leading-relaxed">
                    Either party may terminate the service agreement with 30 days' written notice. We reserve the right to suspend or terminate your access immediately if you breach these terms. Upon termination, your right to use our services will cease immediately.
                  </p>
                </section>

                <section>
                  <h2 className="text-2xl font-bold text-foreground mb-4">Confidentiality</h2>
                  <p className="text-muted-foreground leading-relaxed">
                    Both parties agree to maintain the confidentiality of any proprietary information shared during the course of our business relationship. This obligation survives termination of services.
                  </p>
                </section>

                <section>
                  <h2 className="text-2xl font-bold text-foreground mb-4">Governing Law</h2>
                  <p className="text-muted-foreground leading-relaxed">
                    These terms shall be governed by and construed in accordance with applicable laws, without regard to conflict of law principles. Any disputes arising from these terms shall be resolved through binding arbitration.
                  </p>
                </section>

                <section>
                  <h2 className="text-2xl font-bold text-foreground mb-4">Changes to Terms</h2>
                  <p className="text-muted-foreground leading-relaxed">
                    We reserve the right to modify these terms at any time. We will notify users of any material changes via email or through our services. Continued use of our services after changes constitutes acceptance of the modified terms.
                  </p>
                </section>

                <section>
                  <h2 className="text-2xl font-bold text-foreground mb-4">Contact Information</h2>
                  <p className="text-muted-foreground leading-relaxed">
                    For questions about these Terms of Service, please contact us at day@advanai.net.
                  </p>
                </section>
              </div>
            </div>
          </div>
        </section>
      </main>
      <Footer />
    </>
  )
}
